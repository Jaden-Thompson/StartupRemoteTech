# Job Scraper Application

## Overview

This is a Python Flask web application that scrapes remote tech job listings from startup companies. The application focuses on finding positions that don't require college degrees, specifically targeting startup environments with tech-focused roles.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Web Scraping**: BeautifulSoup4 and Trafilatura for HTML parsing and content extraction
- **HTTP Requests**: Requests library with session management and custom headers
- **Threading**: Background job processing using Python's threading module
- **Template Engine**: Jinja2 (built into Flask)

### Frontend Architecture
- **HTML Templates**: Server-side rendered templates using Jinja2
- **Styling**: Custom CSS with Font Awesome icons
- **JavaScript**: Client-side interaction for form handling and real-time updates
- **Responsive Design**: Mobile-friendly interface

### Data Processing
- **Filtering System**: Custom JobFilter class with regex-based content analysis
- **Export Functionality**: CSV and JSON export capabilities
- **Real-time Updates**: WebSocket-like polling for scraping progress

## Key Components

### Core Application (app.py)
- Flask application with routes for scraping control and data export
- Background thread management for non-blocking scraping operations
- Global state management for scraping results and status
- RESTful API endpoints for frontend communication

### Web Scraper (scraper.py)
- JobScraper class with configurable scraping parameters
- Rate limiting and respectful scraping practices
- Multiple site support (RemoteOK, Wellfound)
- Session management with proper User-Agent headers

### Content Filtering (filters.py)
- JobFilter class for intelligent job classification
- Degree requirement detection using regex patterns
- Tech keyword identification and scoring
- Startup company identification
- Internship and unpaid position filtering

### Frontend Interface
- **Main Page**: Configuration form for scraping parameters
- **Results Page**: Filtered job listings with export options
- **Styling**: Modern, responsive design with gradient headers

## Data Flow

1. **User Configuration**: User sets scraping parameters through web interface
2. **Background Scraping**: Flask starts scraping in separate thread to avoid blocking
3. **Content Extraction**: Scraper fetches job listings from configured sites
4. **Intelligent Filtering**: Jobs are filtered based on multiple criteria:
   - No degree requirements
   - Tech-focused roles
   - Startup companies preferred
   - Excludes internships/unpaid positions
5. **Result Storage**: Filtered results stored in memory for immediate access
6. **Data Export**: Users can export results in CSV or JSON format

## External Dependencies

### Web Scraping Libraries
- **BeautifulSoup4**: HTML parsing and DOM navigation
- **Trafilatura**: Advanced content extraction and text processing
- **Requests**: HTTP client with session management
- **lxml**: Fast XML and HTML processing backend

### Web Framework
- **Flask**: Lightweight web framework for routing and templating
- **Jinja2**: Template engine (included with Flask)

### Development Tools
- **uv**: Modern Python package manager
- **Python 3.11**: Runtime environment

### Target Websites
- **RemoteOK**: Remote job aggregation platform
- **Wellfound (AngelList)**: Startup-focused job platform

## Deployment Strategy

### Environment Setup
- **Runtime**: Python 3.11 with Nix package management
- **Package Management**: UV for dependency resolution and installation
- **Port Configuration**: Flask development server on port 5000

### Deployment Configuration
- **Development**: Local Flask development server with auto-reload
- **Dependencies**: Automatic installation via UV package manager
- **Process Management**: Single-process deployment with background threading

### Scaling Considerations
- **Memory Management**: In-memory result storage (suitable for single-user deployment)
- **Rate Limiting**: Built-in delays to respect target site policies
- **Error Handling**: Graceful degradation for site unavailability

## Recent Changes

- June 20, 2025: Enhanced visual design with glassmorphism effects and gradient backgrounds
- June 20, 2025: Added LinkedIn job scraping with recruiter information extraction
- June 20, 2025: Added "no experience required" filtering to exclude jobs requiring specific years of experience  
- June 20, 2025: Expanded to scrape from 6 job boards (RemoteOK, Wellfound, WeWorkRemotely, Remotive, JustRemote, LinkedIn)
- June 20, 2025: Added reset functionality to handle stuck scraping states
- June 20, 2025: Enhanced job cards with recruiter contact information display

## Changelog

- June 20, 2025: Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.